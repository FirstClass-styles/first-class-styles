FIRST CLASS STYLES — GALLERY IMAGE PACKAGE

Upload the five gallery photos to public/gallery/.

Files:
- gallery-straight-and-curls.jpg
- gallery-twist-style.jpg
- gallery-blonde-waves.jpg
- gallery-curly-style.jpg
- gallery-long-layers.jpg

Keep promo-shampoo-blow-dry.jpg separate from the client hairstyle gallery.
These are optimized copies; originals are not modified.
